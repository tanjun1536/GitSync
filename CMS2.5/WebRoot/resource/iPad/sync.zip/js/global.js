﻿function setContentDiv() {
    $(".contentDiv").each(function () {
        $(this).height($(this).parent().height() - 36);
    });
    
}
function goURL(url)
{
	$(location).attr('href',url);
}