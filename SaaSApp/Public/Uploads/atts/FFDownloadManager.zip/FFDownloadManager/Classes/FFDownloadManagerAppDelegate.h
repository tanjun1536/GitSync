//
//  FFDownloadManagerAppDelegate.h
//  FFDownloadManager
//
//  Created by Futao on 10-12-30.
//  Copyright 2010 http://www.ftkey.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FFDownloadManagerViewController;

@interface FFDownloadManagerAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    FFDownloadManagerViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet FFDownloadManagerViewController *viewController;

@end

