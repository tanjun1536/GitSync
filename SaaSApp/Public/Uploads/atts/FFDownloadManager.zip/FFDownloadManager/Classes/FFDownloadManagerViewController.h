//
//  FFDownloadManagerViewController.h
//  FFDownloadManager
//
//  Created by Futao on 10-12-30.
//  Copyright 2010 http://www.ftkey.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DownloadManager.h"
@interface FFDownloadManagerViewController : UIViewController <DownloadManagerDelegate>{
	DownloadManager *download;
}

@end

